﻿namespace Bosch.Calculator
{
    public class AdvanceMath
    {
        public double Square(double num) { return num * num; }
        public double SquareRoot(double num)
        {
            return Math.Sqrt(num);
        }
    }
}