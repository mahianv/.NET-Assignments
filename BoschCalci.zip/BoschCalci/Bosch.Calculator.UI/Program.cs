﻿using BC = Bosch.Calculator;

namespace Bosch.Calculator.UI
{
    internal class Program
    {
        static void Main(string[] args)
        {
            BC.BasicMath basic = new BC.BasicMath();
            BC.AdvanceMath advance = new BC.AdvanceMath();
            Console.WriteLine(basic.Add(100, 150));
            Console.WriteLine(basic.Subtract(200, 100));
            Console.WriteLine(basic.Multiply(20, 30));
            Console.WriteLine(basic.Divide(20, 5));
            Console.WriteLine(advance.Square(5));
            Console.WriteLine(advance.SquareRoot(25));
            Console.ReadKey();

        }
    }
}