﻿using System.Runtime.InteropServices;
using Bosch.eCommerce.Models;
using Microsoft.EntityFrameworkCore;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Bosch.eCommerce.Dal
{
    public class eCommerceDbContext : DbContext
    {
        public eCommerceDbContext()
        {
            
        }
        public eCommerceDbContext(DbContextOptions<eCommerceDbContext> options) : base(options)
		{ 
		}
        public DbSet<Category> Categories { get; set; }
		public DbSet<Product> Products { get; set; }
		public DbSet<Customer> Customers { get; set; }
		public DbSet<Cart> Cart{ get; set; }
		public DbSet<CartItem> CartItems { get; set; }
		public DbSet<Invoice> Invoices{ get; set; }

		protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
		{
			if (!optionsBuilder.IsConfigured)
			{

				optionsBuilder.UseSqlServer(@"Data Source = KOR-C-0016F\SQLEXPRESS;Initial Catalog = BoschEcomJuly24Db; Trusted_Connection = true; TrustServerCertificate = True;");
			}
		}


	}
}
