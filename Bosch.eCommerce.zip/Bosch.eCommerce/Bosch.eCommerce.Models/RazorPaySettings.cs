﻿namespace Bosch.eCommerce.Models
{
    public class RazorPaySettings
    {
        public string? Key { get; set; }
        public string? Secret { get; set; }
    }
}
