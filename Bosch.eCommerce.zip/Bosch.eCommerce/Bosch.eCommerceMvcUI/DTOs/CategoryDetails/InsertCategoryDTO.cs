﻿namespace Bosch.eCommerceMvcUI.DTOs.CategoryDTO
{
    public class InsertCategoryDTO
    {
        public string CategoryName { get; set; } = string.Empty;

        public string Description { get; set; } = string.Empty;
    }
}
