﻿namespace Bosch.eCommerceMvcUI.DTOs.CartItemDTOs
{
    public class InsertCartItemDTO
    {
        public int  ProductId { get; set; }

        public int CartId { get; set; }
        public int Quantity { get; set; } = 1;

        public int size { get; set; } = 7;
    }
}
