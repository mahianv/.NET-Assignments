﻿using AutoMapper;
using Bosch.eCommerce.Models;
using Bosch.eCommerceMvcUI.DTOs.ProductDTO;

namespace Bosch.eCommerceMvcUI.Profiles
{
    public class ProductProfile : Profile
    {
        public ProductProfile()
        {
            CreateMap<Product, ProductDTO>();
            
        }

    }
}
