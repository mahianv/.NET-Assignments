﻿using AutoMapper;
using Bosch.eCommerce.Models;
using Bosch.eCommerceMvcUI.DTOs.CategoryDTO;

namespace Bosch.eCommerceMvcUI.Profiles
{
    public class CategoryProfile :Profile // need to import the automapper
    {
        public CategoryProfile()
        {
            CreateMap<Category, CategoryDTO>();
            CreateMap<InsertCategoryDTO, Category>();
            
        }
    }
}
