﻿
using AutoMapper;

using Bosch.eCommerce.Models;

using Bosch.eCommerceMvcUI.DTOs.CartItemDTOs;
 
namespace Bosch.eCommerceMvcUI.Profiles

{

    public class CartItemProfile : Profile

    {

        public CartItemProfile()

        {

            CreateMap<InsertCartItemDTO,CartItem>();

        }

    }

}

 