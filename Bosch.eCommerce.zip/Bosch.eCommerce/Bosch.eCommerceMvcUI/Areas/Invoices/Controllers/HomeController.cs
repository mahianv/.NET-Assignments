﻿using Microsoft.AspNetCore.Mvc;

namespace Bosch.eCommerceMvcUI.Areas.Invoices.Controllers
{
    [Area("Invoice")]
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
			ViewBag.PageTitle = "Welcome to Bosch Invoice List!";
			return View();
			
        }
    }
}
