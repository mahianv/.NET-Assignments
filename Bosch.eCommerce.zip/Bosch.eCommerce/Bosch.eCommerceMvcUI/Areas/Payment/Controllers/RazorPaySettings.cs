﻿namespace Bosch.eCommerceMvcUI.Areas.Payment.Controllers
{
    public class RazorPaySettings
    {

    }
}