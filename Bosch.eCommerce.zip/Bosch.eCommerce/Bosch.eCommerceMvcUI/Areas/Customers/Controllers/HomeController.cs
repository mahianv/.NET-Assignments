﻿using Microsoft.AspNetCore.Mvc;

namespace Bosch.eCommerceMvcUI.Areas.Customers.Controllers
{
    [Area("Customers")]
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
			ViewBag.PageTitle = "Welcome to Bosch Customers List!";
			return View();
		}
    }
}
