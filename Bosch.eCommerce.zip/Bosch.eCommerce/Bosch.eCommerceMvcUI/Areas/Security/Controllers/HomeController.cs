﻿using Microsoft.AspNetCore.Mvc;

namespace Bosch.eCommerceMvcUI.Areas.Security.Controllers
{
    [Area("Security")]
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            ViewBag.PageTitle = "Welcome to Bosch Security List!";
            return View();
        }
    }
}
