﻿using AutoMapper;
using Bosch.eCommerce.Models;
using Bosch.eCommerce.Persistance;
using Bosch.eCommerceMvcUI.DTOs.ProductDTO;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Bosch.eCommerceMvcUI.Areas.Products.Controllers
{
    [Area("Products")]
    public class HomeController : Controller
    {
        private readonly ICommonRepository<Product> _productRepository;
        private readonly ICommonRepository<Category> _categoryRepository;
        private readonly IMemoryCache _productsCache;
        private readonly IMapper _mapper;

        public HomeController(ICommonRepository<Product> productRepository, ICommonRepository<Category> categoryRepository = null, IMemoryCache productsCache = null, IMapper mapper = null)
        {
            _productRepository = productRepository;
            _categoryRepository = categoryRepository;
            _productsCache = productsCache;
            _mapper = mapper;
        }

        //public async Task<IActionResult> Index()
        //{
        //    ViewBag.PageTitle = "Welcome to Bosch Product List!";
        //    IEnumerable<Product> cachedProducts;
        //    if (_productsCache.TryGetValue("ProductsList", out cachedProducts))
        //    {
        //        return View(cachedProducts);
        //    }
        //    MemoryCacheEntryOptions cacheOptions = new()
        //    {
        //        AbsoluteExpiration = DateTimeOffset.UtcNow.AddMinutes(2),
        //        SlidingExpiration = new TimeSpan(0, 0, 40)
        //    };
        //    var products = await _productRepository.GetAllAsync();
        //    _productsCache.Set("ProductsList", products, cacheOptions);
        //    return View(products);
        //}
        public async Task<IActionResult> Index(int pageNumber = 1)
        {
            ViewBag.PageTitle = "Welcome to Bosch Product List!";
            const int PageSize = 4;
            var products = _mapper.Map<IEnumerable<ProductDTO>>(await _productRepository.GetAllAsync());
            var totalItems = products.Count();
            var pagedProducts = products.Skip((pageNumber - 1) * PageSize).Take(PageSize).ToList();

            ViewBag.CurrentPage = pageNumber;
            ViewBag.TotalPages = (int)Math.Ceiling((double)totalItems / PageSize);

            return View(pagedProducts);
        }
        public async Task<IActionResult> Details(int id)
        {
            var product = (await _productRepository.GetDetailsAsync(id));
            ViewBag.PageTitle = $"Details of - {product.ProductName}";
            return View(product);
        }
        //public async Task<IActionResult> CategoryWiseProducts(int id)
        //{
        //    string CategoryName = (await _categoryRepository.GetDetailsAsync(id)).CategoryName;
        //    ViewBag.PageTitle = $"Bosch Product List From Category - {CategoryName}!";
        //    var products = (await _productRepository.GetAllAsync()).Where(product => product.CategoryId == id);
        //    return View("Index",products);
        //}
        public async Task<IActionResult> CategoryWiseProducts(int id, int pageNumber = 1)
        {
            const int PageSize = 4;
            var category = await _categoryRepository.GetDetailsAsync(id);
            if (category == null)
            {
                return NotFound();
            }

            string categoryName = category.CategoryName;
            ViewBag.PageTitle = $"Bosch Products List from Category - {categoryName}!";
            ViewBag.CategoryId = id;

            var products = _mapper.Map<IEnumerable<ProductDTO>>(await _productRepository.GetAllAsync()).Where(product => product.ProductId == id);
            var totalItems = products.Count();
            var pagedProducts = products.Skip((pageNumber - 1) * PageSize).Take(PageSize).ToList();

            ViewBag.CurrentPage = pageNumber;
            ViewBag.TotalPages = (int)Math.Ceiling((double)totalItems / PageSize);

            return View("Index", pagedProducts);
        }
    }
}