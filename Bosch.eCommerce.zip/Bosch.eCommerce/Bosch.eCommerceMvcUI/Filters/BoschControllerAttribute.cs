﻿using System;
using Microsoft.AspNetCore.Mvc.Filters;

namespace Bosch.eCommerceMvcUI.Filters
{
    public class BoschControllerAttribute : Attribute, IActionFilter
    {
        public void OnActionExecuted(ActionExecutedContext context)
        {
            Console.WriteLine("I am controller action method - OnActionExecuted!");
        }

        public void OnActionExecuting(ActionExecutingContext context)
        {
            Console.WriteLine("I am controller action method - OnActionExecuting!"); 
        }
    }
}
